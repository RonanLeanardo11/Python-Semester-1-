#Ronan Breen X00152190
#Lab 3 Exercise 1
#Create a program to read values representing a time duration in hours, minutes, and  seconds, then print the equivalent total number of seconds.

# Variables - define how many seconds in a min, seconds in an hour
Seconds_per_minute = 60
Seconds_per_hour = 3600


# Inputs - user inputs value of time in Hours, Mins, seconds
Hours = int(input("Enter amount of hours : "))
Minutes = int(input("Enter amount of minutes : "))
Seconds = int(input("Enter amount of seconds : "))

# Formula - Totals the amount user enters by seconds per (hour, minute, second). Total overall add the other 3 up and this is then what gets outputted
Total_Hours = (Hours * Seconds_per_hour)
Total_Minutes = (Minutes * Seconds_per_minute)
Total_Seconds = (Seconds)
Total_Overall = (Total_Hours + Total_Minutes + Total_Seconds)

# Output
print("The total number of seconds is {}".format(Total_Overall))