#Ronan Breen X00152190
#Lab 3 Exercise 3
#BigBurgers Ltd require a program to calculate their profit on hamburgers and chips each day.
#• A portion of chips cost the company 30p and sells at 75p.
#• A hamburger costs 40p and sells at 95p.
#• Input to the program is the number of hamburgers and the number of portions of chips sold.
#• Output is the profit on hamburgers, the profit on chips and the total profit

# Variables - define cost, selling price and how profit is calculated per item.
Chips_Cost = .30
Chips_Sell = .75
Profit_Per_Chip = (Chips_Sell - Chips_Cost)
Hamburger_Cost = .40
Hamburger_Sell = .75
Profit_Per_Hamburger = (Hamburger_Sell - Hamburger_Cost)

# Input - user enters total Chips, Hamurgers sold
Total_Chips_Sold = int(input("Enter total Chips Sold : "))
Total_Hamburgers_Sold = int(input("Enter total Hamburgers Sold : "))

# Formula - Calculates profir per item.
Total_Chips_Profit = int(Total_Chips_Sold * Profit_Per_Chip)
Total_Hamburgers_Profit = int(Total_Hamburgers_Sold * Profit_Per_Hamburger)

# Output - The profit on each item in Euros.
print("The total profits on Chip sales is €{} ".format(Total_Chips_Profit))
print("the total profits on Hamburger sales is €{} ".format(Total_Hamburgers_Profit))