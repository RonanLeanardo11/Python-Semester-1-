#Ronan Breen X00152190
#Lab 3 Exercise 2
#Write a program that reads a value representing a number of seconds. Print the equivalent amount of time in hours, minutes, and seconds

#Input - user enters time time taken in seconds
Value_Seconds = int(input("Seconds taken to run programme: "))

#Varibles - calculates seconds as seconds/minutes/hours
Seconds = (Value_Seconds)
Minutes = (Seconds/60)
Minutes = round(Minutes,2)
Hours = (Minutes/60)
Hours = int(round(Hours,0))

#Formula - outputs as secoonds, minutes, hours
print("The number of Seoonds programme takes is {} seconds".format(Seconds))
print("The number of Minutes programme takes is {} minutes".format(Minutes))
print("The number of Hours programme takes is {} hours".format(Hours))