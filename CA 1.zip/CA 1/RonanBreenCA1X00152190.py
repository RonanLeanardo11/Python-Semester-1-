# Ronan Breen/ X00152190
# SDF CA1 - Console App to allow a user to book a cinema ticket

import datetime # This will be used to determine when kids Club pricing should occur (as only applicable on Saturday mornings)

# Inputs
AdultPeakTicket = 12
AdultOffPeakTicket = 8
KidsClubTicket = 3.50 #Assumption that only Children can purchase Kids Club tickets

# Conditions
# Senior Citizens = 65 and over
# Adults = 16 - 64
# Children = 15 and under
# Kids Club = only Sat Mornings i.e. before 12pm

# Variables (all Tikcet prices as a % of Adult prices, rounded to 2 decimal places for display purposes
ChildOffPeakTicket = (AdultOffPeakTicket * .5) # 50% of adult off peak ticket
ChildOffPeakTicket = round(ChildOffPeakTicket,2)
#print(ChildOffPeakTicket) - just checking calculation ok, not part of code
ChildPeakTicket = (AdultPeakTicket * .5) # 50% of adult peak ticket
ChildPeakTicket = round(ChildPeakTicket,2)
StudentOffPeakTicket = (AdultOffPeakTicket * .6) # 60% of adult off peak ticket
StudentOffPeakTicket = round(StudentOffPeakTicket,2)
StudentPeakTicket = (AdultPeakTicket * .6) # 60% of adult peak ticket
StudentPeakTicket = round(StudentPeakTicket,2)
SeniorOffPeakTicket = (AdultOffPeakTicket * .75) # 75% of adult off peak ticket
SeniorOffPeakTicket = round(SeniorOffPeakTicket,2)
SeniorPeakTicket =  (AdultPeakTicket * .75) # 75% of adult peak ticket
SeniorPeakTicket = round(SeniorPeakTicket,2)

# Calculations

UserAge = int(input("Please Enter your age: "))

# Adult and Student Tickets
# Defines age bands for Adult and Students
if UserAge >= 16 and UserAge <= 64:
    print("You are an Adult")
    # Student Pricing
    IsAdultStudent = input("Are you a Student (y/n). Please enter in format given: ")
    if IsAdultStudent == "y": # Defines Adult as a student
        ViewingTimes = input("Would you like peak Times (y/n). Please enter in format given: ")
        if ViewingTimes == "y": # Student and Peak Times
            print("You have chosen Student Peak tickets and the total price is €{}".format(StudentPeakTicket))
        elif ViewingTimes == "n": # Student and Off Peak Times
            print("You have chosen Student Off Peak Tickets and the total price is €{}".format(StudentOffPeakTicket))
        else: # Incorrect entry
            print("You have entered an answer in an unknown format. Please enter (y/n) in the format given")
    # Adult Pricing
    elif IsAdultStudent == "n":
        ViewingTimes = input("Would you like peak times (y/n). Please enter in format given: ")
        if ViewingTimes == "y": # Adult and Peak Times
            print("You have chosen Adult Peak Times and the total price is €{}".format(AdultPeakTicket))
        elif ViewingTimes == "n": # Adult and Off Peak Times
            print("You have chosen Adult Off Peak Times and the total price is €{}".format(AdultOffPeakTicket))
    else: # Incorrect entry
        print("Input Invalid. Please amend answer and try again")

# Senior Citizen Pricing
elif UserAge >= 65:
    print("You are a Senior Citizen")
    ViewingTimes = input("Would you like peak Times (y/n). Please enter in format given: ")
    if ViewingTimes == "y": # Senior and Peak Times
        print("You have Chosen Peak Senior Citizen times and the total price is €{}".format(SeniorPeakTicket))
    elif ViewingTimes == "n": # Senior and Off Peak Times
        print("You have chosen Off Peak Senior Citizen Times and the total price is €{}".format(SeniorOffPeakTicket))
    else: # Incorrect entry
        print("Input Invalid. Please amend answer and try again")

# Child Ticket Pricing
elif UserAge >= 0 and UserAge <= 15:
    print("You are a Child")
    ViewingTimes = input("Would you like peak, off peak or kids club. Please enter in format given: ")
    if ViewingTimes == "peak": # Child and Peak
        print("You have chosen Peak Child Times and the total price is €{}".format(ChildPeakTicket))
    elif ViewingTimes == "off peak": # Child and off Peak
        print("You have chosen Off Peak Child Times and total price is €{}".format(ChildOffPeakTicket))
    elif ViewingTimes == "kids club": # Child and Kids Club
        print("You have chosen Kids Club tickets and the total price is €{}".format(KidsClubTicket))
    else: # Incorrect entry
        print("Input Invalid. Please amend answer and try again")

else:
    print("Input Invalid. Please amend answer and try again") # Incorrect entry

print("Thanks for using this service, please enjoy the movie!")
