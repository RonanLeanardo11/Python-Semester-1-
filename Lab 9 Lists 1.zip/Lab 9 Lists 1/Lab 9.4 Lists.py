# Lab 9.4 Lists X00152190
#Exercise 4
# Use the code from the lecture notes for the lotto program, add to this to ensure that no random
# number are repeated in the list, and the any number a user enters is not repeated in the list

import random
lottoNumbers = []
userNumbers = []
number = 0

for number in range(6):
    lottoNumbers.append(random.randint(1, 43))
    if number in lottoNumbers:
        lottoNumbers.remove(lottoNumbers[-1]) # Try and remove last input but not working
        lottoNumbers.append(random.randint(1, 43))
for number in range(6):
        userNumbers.append(int(input("Input lotto number:")))
        if number in userNumbers:
            userNumbers.remove(userNumbers[-1]) # try and remove last input but not working
            userNumbers.append(int(input("Input lotto number:")))

print("Lotto Numbers:", lottoNumbers)
print("Your numbers :", userNumbers)