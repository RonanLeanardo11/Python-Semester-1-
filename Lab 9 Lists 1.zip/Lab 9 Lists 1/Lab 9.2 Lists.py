# Lab 9.2 Iterations Ronan Breen
# Exercise 2
# Write a Python script to take in 5 numbers and store them in a list. Separately go through the list
# and add 1 to each number. Print out the list to test that each number has been incremented by 1.

# List
List = []

# Inputs - Takes in 5 numbers and adds to list
Number1 = int(input("Enter Number: "))
List.append(Number1)
Number2 = int(input("Enter Number: "))
List.append(Number2)
Number3 = int(input("Enter Number: "))
List.append(Number3)
Number4 = int(input("Enter Number: "))
List.append(Number4)
Number5 = int(input("Enter Number: "))
List.append(Number5)
#print(List)

# Output
for i in List:
    i = i+1
    # Extraction = List(i)
    print(i, end=",")