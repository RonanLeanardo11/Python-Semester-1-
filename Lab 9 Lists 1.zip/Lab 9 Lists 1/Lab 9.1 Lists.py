# lab 9.1. Lists Ronan Breen X00152190

# Input
ListDailyRainfall = []
ListWeekdays = []
TotalDays = 7
i = 0

# Loops to ask for days until Total days hit i.e. 7 in this case
while i < (TotalDays):
    i += 1
    ListDailyRainfall.append(int(input("Please enter daily rainfall in cm: ")))
    ListWeekdays.append(str(input("Please enter Day of the week: ")))
# print(ListDailyRainfall)
# print(ListWeekdays)

# Variables - Get Total and Average Rainfall
TotalRainfall = sum(ListDailyRainfall)
TotalRainfall = round(TotalRainfall,0)
print("The Total Rainfall is {}".format(TotalRainfall))
AverageRainfall = (TotalRainfall/TotalDays)
AverageRainfall = round(AverageRainfall,0)
print("The Average Rainfall is {}".format(AverageRainfall))

# Define Variables
MaxRainfall = 3.5
    # get index and item value in ListDailyRainfall. if item value is over 3.5 print the say rainfall exceeded
for i, item in enumerate(ListDailyRainfall):
    if item > MaxRainfall:
       print("Rainfall Exceeded on {}".format(ListWeekdays[i]))
       #print("The rainfall level of {}cm on {} exceeded the average level of 3.5cm".format(ListDailyRainfall[item],ListWeekdays[i]))