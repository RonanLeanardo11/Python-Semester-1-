# Lab 9.3 Lists x00152190 Ronan Breen

# Inputs
TotalSalesPeople = int(input("Enter number of Salespeople on team: "))
TotalNames = [] # Define SalesPeople list
TotalSales = [] # Define Sales figures list

# Exit program is no salespeople.
if TotalSalesPeople <= 0:
    print("No Salespeople confirmed, program exited")

# Output
    # Print Individual Sales
for i in range(0,TotalSalesPeople):
    IndvName = str(input("Please enter your name: "))
    TotalNames.append(IndvName)
    #print(TotalNames)
    IndvSales = int(input("Please enter Sales: "))
    TotalSales.append(IndvSales)
    #print(TotalSales)
    print("{} has made €{} sales".format(TotalNames[i],TotalSales[i]))
    min = TotalSales[0]
    max = TotalSales[0]
    total = 0
    for sale in TotalSales:
        total += sale
        if sale > max:
            max = sale # if number in TotalSales higher than previous then this is now the new max
        if sale < min:
            min = sale # if number in TotalSales lower than the previous then this is now the new min.

average = total/TotalSalesPeople
print("The Maximum sale is €{}".format(max))
print("The Minimum sale is €{}".format(min))
print("The Average sale is €{}".format(average))
print("Total Team Sales is €{}".format(total))

