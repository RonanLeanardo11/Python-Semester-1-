# Lab 4 Exercise 2 Conditional Statements
# Ronan Breen/ X001521190

#input
Item_cost = int(input("Please enter the total cost of the item: ")) # User inputs cost of the item

#Formula and Output - Purchasing policy to be followed by employees

if Item_cost >= 5001: #Item costs more than €5k
    print("Item must go out to Tender")
elif Item_cost >= 501 <= 5000: # Item costs between €501 and €5000
    print("Must get quotes from three different suppliers")
else: # Item less than €501
    print("Proceed and order item")

