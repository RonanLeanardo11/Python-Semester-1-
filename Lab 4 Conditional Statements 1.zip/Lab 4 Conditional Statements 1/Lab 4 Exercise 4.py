# Lab 4 Exercise 4 Conditional Statements
# Ronan Breen/ X00152190

# Input
Password = input("Please enter your password: ") # Customer enters password
Confirm_Password = input("Please confirm your password: ") # Customer confirms password

# Formula and Output - checks if passwords match and advises customer
if Password == Confirm_Password:
        print("Passwords matched Successfully")
else:
    print("Please re-enter passwords as they do not match")


