# Lab 4 Exercise 1 Conditional Statements
# Ronan Breen/ X001521190

#input
value1 = int(input("Please enter numeric Value: ")) #user enters value as an Integer

#Formual and Output

if value1 % 2 == 0: #if the number is divisible by 2
    print("{} is an even number".format(value1))
else:
    print("{} is an odd number".format(value1))

