# Lab 4 Exercise 3 Conditional Statements
# Ronan Breen/ X00152190

#Input
EngineCC = int(input("Please enter the Engine Size (CC) of your vehicle: ")) # User inputs CC as an Int.

# Formula and Output
if EngineCC <= 1000: # CC less than 100 fee is €150
    print("Your Motor Tax Fee is €150")
elif 1001 <= EngineCC <= 1200: # CC between 1001 and 1200 fee is €175
    print("Your Motor Tax Fee is €175")
elif 1201 <= EngineCC <= 1400: # CC between 1201 and 1400 fee is €200
    print("Your Motor Tax Fee is €200")
elif 1401 <= EngineCC <= 1600: # CC between 1401 and 1600 fee is €250
    print("Your Motor Tax Fee is €250")
elif 1601 <= EngineCC <= 1800: # CC between 1601 and 1800 fee is €250
    print("Your Motor Tax Fee is €250")
elif 1801 <= EngineCC <= 2000: # CC between 1801 and 2000 fee is €175
    print("Your Motor Tax Fee is €350")
else: # CC over 2000 fee is €500
    print("Your Motor Tax Fee is €500")
