# Lab 4 Exercise 3 Conditional Statements
# Ronan Breen/ X00152190

#Input
EngineCC = int(input("Please enter the Engine Size (CC) of your vehicle: ")) # User inputs CC as an Int.

# Formula and Output
if EngineCC <= 1000: # Anythign less than 1,000 should be €150
    print("Your Motor Tax Fee is €150")
elif EngineCC <= 1200: # between 1001 and 1200 should be €175
    print("Your Motor Tax Fee is €175")
elif EngineCC <= 1400: # between 1201 and 1400 should be €200
    print("Your Motor Tax Fee is €200")
elif EngineCC <= 1600: # between 1401 and 1600 should be €250
    print("Your Motor Tax Fee is €250")
elif EngineCC <= 1800: # between 1601 and 1800 should be €250
    print("Your Motor Tax Fee is €250")
elif EngineCC <= 2000: # between 1801 and 2000 should be €350
    print("Your Motor Tax Fee is €350")
else: # anything over 2000 should be €500
    print("Your Motor Tax Fee is €500")
