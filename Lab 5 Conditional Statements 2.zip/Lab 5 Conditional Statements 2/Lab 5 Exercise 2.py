# Lab 5 Exercise 2 Conditional Statements
# Ronan Breen/ X00152190

# User Input
Hours_Worked = int(input("Please enter your total hours worked this week: ")) # User enter hours worked this week

# fixed inputs
Standard_week = 39
Standard_Hourly_pay = 35
Overtime_Hourly_pay = 50
Tax_Under_18K = 0
Tax_over_18k = 0.21

# Formula
# Calculate Weekly Pay if working standard hours and if working overtime
if Hours_Worked <= 39:
    Standard_Weekly_Pay = (Hours_Worked * Standard_Hourly_pay) # Hours Worked * standard pay
    Weekly_Pay = Standard_Weekly_Pay
    Overtime_weekly_pay = 0 # No overtime if work 39 hours or less
elif Hours_Worked >= 40:
    Standard_Weekly_Pay = (Standard_week * Standard_Hourly_pay) #Standard hours * standard pay
    Overtime_weekly_pay =(Hours_Worked - Standard_week)* Overtime_Hourly_pay # Hours worked over 39 (standard) * €50 (overtime hourly pay.
    Weekly_Pay = (Standard_Weekly_Pay + Overtime_Hourly_pay) # add standard and overtime pay

# Calculate Yearly Hours Worked
Yearly_Hours_Worked = (Hours_Worked * 52)

# Calculate Total Standard and Overtime pay for the year
Standard_Yearly_Pay = (Standard_Weekly_Pay * 52) # Standard Weekly multiplied by 52 weeks in year
Overtime_Yearly_pay = (Overtime_weekly_pay * 52) # Overtime weekly multiplied by 52 weeks in year

# Calculate Gross and Net Pay for the Year
Gross_Pay = (Standard_Yearly_Pay + Overtime_Yearly_pay)
if Gross_Pay <= 18000:
    Net_Pay = Gross_Pay # No Tax less than 18k so Gross Pay will equal Net
    Total_Tax = Tax_Under_18K   # Tax Bracket is 0% less than 18k
    Total_Tax = round(Total_Tax,0)
elif Gross_Pay >= 18001:
    Total_Tax = ((Gross_Pay - 18000) * Tax_over_18k) # Tax is based on pay over 18k at a rate of 21%
    Total_Tax = round(Total_Tax, 0)
    Net_Pay = (Gross_Pay - Total_Tax) # net pay is Gross less Tax amount


# output
print("Hours Worked: {} Hours".format(Yearly_Hours_Worked))# Hours worked :
Yearly_Hours_Worked = round(Yearly_Hours_Worked,0)
print("Standard Pay: €{}".format(Standard_Yearly_Pay))# Standard pay amount :
Standard_Yearly_Pay = round(Standard_Yearly_Pay,0)
print("Overtime Pay: €{}".format(Overtime_Yearly_pay))# Over-time pay amount :
Overtime_Yearly_pay = round(Overtime_Yearly_pay,0)
print("Gross Pay: €{}".format(Gross_Pay))# Gross Pay :
Gross_Pay = round(Gross_Pay,0)
print("Total Tax: €{}".format(Total_Tax))# Total Tax :
Total_Tax = round(Total_Tax,0)
print("Net Pay: €{}".format(Net_Pay))# Net Pay
Net_Pay = round(Net_Pay,0)