# Lab 5 Exercise 1 Conditional Statements 2
# Ronan Breen/ X00152190

# Variables
import math # import maths
math.pi
pi = 22/7 # define pi as 22/7
pi = float(pi) #define pi as a floating number
# print("{}".format(pi)) # # can uncomment to confirm pi is correct - just for developer to check when running code.

# input
# The radius measurement should be input by the user
Radius_Input = float(input("Please enter the radius to two decimal points e.g. 12.24 : "))
if Radius_Input <= 0: # If a negative value or 0 is given for the radius, then output an error message
    print("You cannot enter a negative number please retry")


# formula and output
# calculates the area of a circle. This is calculated by (pi * Radius(to the power of 2)
Area_Circle = pi * (Radius_Input ** 2)
Area_Circle = round(Area_Circle,2)
print("The Area of a Circle for Radius {} is {}".format(Radius_Input, Area_Circle))
# volume of a sphere given the radius = V = ⁴⁄₃πr³. First caclulate the Radius to power of 3, then 4/3 and multiple from left to right.
Volume_Sphere = (4/3) * pi * (Radius_Input ** 3)
Volume_Sphere = round(Volume_Sphere,2)
print("The Volume of a Sphere for Radius {} is {}".format(Radius_Input, Volume_Sphere))