# CA2 SDF Ronan Breen X00152190
# 18.12.18
from statistics import mean
# Lists
ListGrades = ["A", "B+", "B", "B-", "C+", "C", "D","F"]
ListMarkRange = ["80-100", "70-79", "60-69", "55-59", "50-54", "40-49", "35-39", "0-34"]
ListStudentsMarks = [] # Holds Student Marks
GradesObtained = []

#Inputs
#Handles all Grade Classifications
A = B_Plus = B = B_Minus = C_Plus = C = D = F = 0

# Loop Control Variable
UserOption = 1

# Display Menu option
while UserOption != 2:
    print()
    print("Grade Entering System")
    print("**********************")
    print("1. \tEnter Student Grades (1)")
    print("2. \tExit (2)")

    #If Option 1 Selected

    #Print Screen Title

    #Prompt user to enter how many Students they are inputting results for
    How_Many_Marks = (int(input("Please enter how many marks you are inputting: ")))

    #Error handling if less than 1 entered
    if How_Many_Marks < 1:
        print("Invalid Number of Marks")

    #Used to Calculate running Total Sales
    Total = float(0)
    StudentOfTheYear = 0

    # Loop until all marks are entered for each student
    for student in range(How_Many_Marks):
        StudentsMarks = float(input("Enter Marks for Student: "))
        while StudentsMarks < 0 or StudentsMarks > 100: # Loop to handle if marks entered outside of Mark Range
            print("Marks must be between 0-100")
            StudentsMarks = float(input("Enter Marks for Student: "))
            if StudentMarks > StudentOfTheYear:
                StudentOfTheYear = (student + 1)
        ListStudentsMarks.append(StudentsMarks) # Adds marks to listStudentMarks

       #Total
        Total += ListStudentsMarks[student] # Sums total Student marks

    #print(ListStudentsMarks)
    #print(Total)


        # Work out Grade Classification
        if ListStudentsMarks[student] > 0 and ListStudentsMarks[student] <= 34:  # Grade F
            F += 1
        elif ListStudentsMarks[student] >= 35 and ListStudentsMarks[student] <= 39:  # Grade D
            D += 1
        elif ListStudentsMarks[student] >= 40 and ListStudentsMarks[student] <= 49:  # Grade C
            C += 1
        elif ListStudentsMarks[student] >= 50 and ListStudentsMarks[student] <= 54:  # Grade C+
            C_Plus += 1
        elif ListStudentsMarks[student] >= 55 and ListStudentsMarks[student] <= 59:  # Grade B-
            B_Minus += 1
        elif ListStudentsMarks[student] >= 60 and ListStudentsMarks[student] <= 69:  # Grade B
            B += 1
        elif ListStudentsMarks[student] >= 70 and ListStudentsMarks[student] <= 79:  # Grade B+
            B_Plus += 1
        elif ListStudentsMarks[student] >= 80 and ListStudentsMarks[student] <= 100:  # Grade A
            A += 1
            #GradesObtained.append(F,0)
            #print("GradesObtained is {}".format(GradesObtained))


    print("{0:<30}".format("Grade Classification"), "{0:<30}".format("Mark Range"), "{0:<30}".format("Grades Obtained"))
    for i, Grade in enumerate(ListGrades):
        print("{0:<30}".format(Grade), "{0:<30}".format(ListMarkRange[i]),"{0:<30}".format("Grades Obtained"))

    TotalMarks = sum(ListStudentsMarks)
    print("The Total Marks are {}".format(TotalMarks))# Sums total Student marks
    AverageMarks = (Total / How_Many_Marks)
    print("The Average Marks per student was {} ".format(AverageMarks))
    print("Student of the year is {}".format(StudentOfTheYear))

    elif user_option != 2 and user_option != 1:
    print("Error invalid option selected. Please try again.\n")
