# Ronan Breen / X00152190
# Code to convert Fah Temp into Celsius

# Variables Conversion factors defined below
Base = 32
Conversion_Factor = (5/9)

# Inputs
Fah_Temp = 35

#Formula Convert Fahrenheit to Temp
Celsius = (Conversion_Factor) * (Fah_Temp - Base)
Celsius = round(Celsius,3)

#Output Temp in Fahrenheit and Celsius
print("Fahrenheit Temp is {} ".format(Fah_Temp))
print("Celsius Temp is {} ".format(Celsius))
print(type(Fah_Temp))
print(type(Celsius))
