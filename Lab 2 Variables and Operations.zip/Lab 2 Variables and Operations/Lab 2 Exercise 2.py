# Ronan Breen/ X00152190
# Code to calculate time it takes to cut grass for given Yard/House Dimensions

# Inputs - Hard code values below.
Yard_Length = 25.2
Yard_Width = 15.3
House_Length = 22.0
House_Width = 16.0

# Variables - Calculated Sq metres of house and yard
Yard_Sq_Metres = (Yard_Length * Yard_Width)
House_Sq_Metres = (House_Length * House_Width)
Cutting_Time = (2) # 2 Square metres per second

#Formula (Want to get the difference between Yard and House and divide by time it takes to cut 1 sq metre per second)
Time_Cut_Grass = (Yard_Sq_Metres - House_Sq_Metres)/ Cutting_Time
Time_Cut_Grass = int(round(Time_Cut_Grass,0))

# Output Time it takes to cut the grass.
print("The times it takes to cut the grass is {} minutes".format(Time_Cut_Grass))