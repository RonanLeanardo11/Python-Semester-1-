#Ronan Breen X00152190
#Lab 2 Exercise 4
#Formula converts 60 miles to kilometres

# Variables
Kilometres_Conversion_Factor = (1/1.60935)

# Inputs Miles shown as kilometres and KM coversion factor is how we would get KM's per Miles.
Miles = 1.60935
Miles = round(Miles,2)
Kilometres_Conversion_Factor = (1/1.60935)
Kilometres_Conversion_Factor = round(Kilometres_Conversion_Factor,2)

#  Formula multiplying miles (in Km's) by 60 and declaring value in KM's
Kilometres = (Miles * 60)
Kilometres = round(Kilometres,2)

# Output showing 60 miles in KM's but also what 1 mile equals and what 1 km equals for future use.
print("60 Miles is equal to {} Kilometeres".format(Kilometres))
print("1 Mile is equal to {} Kilometres".format(Miles))
print("1 Kilometre is equal to {} Miles".format(Kilometres_Conversion_Factor))

# If wanted converted back to Kilometres
Kilometres_60Miles = Kilometres * Kilometres_Conversion_Factor
Kilometres_60Miles = round(Kilometres_60Miles,1)
print("96.6 Kilometres is the equivalent of {} Miles".format(Kilometres_60Miles))