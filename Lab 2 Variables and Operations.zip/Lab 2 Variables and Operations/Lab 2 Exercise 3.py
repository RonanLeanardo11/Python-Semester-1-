# Ronan Breen/ X00152190
# program that assigns two floating point numbers and prints their sum, difference, and the product.

# Inputs - defines both numbers as floats.
Number_1 = float(12.22)
Number_2 = float(14)

# Formula - Lines 9-10 add numbers, 11-12 subtracts numbers, and 13-14 multiplies them.
Sum_Numbers = (Number_1 + Number_2)
Sum_Numbers = round(Sum_Numbers,2)
Difference_Numbers = (Number_1 - Number_2)
Difference_Numbers = round(Difference_Numbers,0)
Product_Numbers = (Number_1 * Number_2)
Product_Numbers = round(Product_Numbers, 2)

# Output - Sum, Difference, Product
print("The sum of both numbers is {}".format(Sum_Numbers))
print("The difference between the numbers is {}".format(Difference_Numbers))
print("The product of both numbers is {}".format(Product_Numbers))