# Ronan Breen Lab 7.2 X00152190

#input
Sentence = str(input("Please enter your sentence: "))

#Variables
Spaces = ""
SpaceEnc = str("%20")
SpaceCount = 0

# Output - Still working on
for Words in Sentence:
    if Words == " ":
        SpaceCount += 1
        NewSentence = Sentence.split("%20")

print("Total Spaces in the Sentence are {}".format(SpaceCount))
print(NewSentence)


