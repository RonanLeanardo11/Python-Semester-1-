# Ronan Breen Lab 7.1 X00152190

# Variables
a = 0
b = 1

# UserInput
UserInput = int(input("Please enter number of terms: "))
#UserInput2 = int(input("Please enter ending term number: "))

# Formula
for n in range(0,UserInput + 1): # define range from 0 to last term number (+1 makes it inclusive of last term)
    if UserInput >= 1:
        print(a) # A starts at zero but formula below makes A = B (where B starts at 1 and is incrementing with last A number).
        a, b = b, a + b # therfore A= 0 printed above but when loops we make A = B(1) nad continue until we have added two previous numbers * number of terms.
    elif UserInput < 1:
        print("Term must be greater than Zero")

print("Thank you for using the service")