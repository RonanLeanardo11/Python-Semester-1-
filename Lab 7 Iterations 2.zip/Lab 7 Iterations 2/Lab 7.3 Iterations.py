# Ronan Breen Lab 7.3 X00152190

# Inputs
Sentence = str(input("Please Enter your Sentence: "))
CharList = str(input("Are you happy to Proceed (y/n)?: "))
#Charachter1 = Charachter1.capitalize()

# variables
counter = 0
#print(Charachter1)

# Output - if customer enters more charachters than y/n, more than once programs asks to repeat until only one charachter = y/n entered.
for char in CharList:
        while len(CharList) > 1 or CharList != "y" or Charlist != "n":
            CharList = str(input("Are you happy to Proceed (y/n)? **Please enter a single charachter only: "))
        for word in Sentence:
            if word.__contains__(char):
                counter += 1

print("User has inputted {} {} times in the sentence".format(CharList, counter), end="")