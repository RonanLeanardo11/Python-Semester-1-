# Lab 10 Lists X00152190

# Initial Lists and Input
CanName = []
CanVotes = []
CandidatesNumber = 5

# Inputs - Scores
print("*** Election Process Votes Counter ***\n")
CanName.append(str(input("Please enter Candidate surname: ")))
CanVotes.append(int(input("Votes Received by Candidate: ")))
CanName.append(str(input("Please enter Candidate surname: ")))
CanVotes.append(int(input("Votes Received by Candidate: ")))
CanName.append(str(input("Please enter Candidate surname: ")))
CanVotes.append(int(input("Votes Received by Candidate: ")))
CanName.append(str(input("Please enter Candidate surname: ")))
CanVotes.append(int(input("Votes Received by Candidate: ")))
CanName.append(str(input("Please enter Candidate surname: ")))
CanVotes.append(int(input("Votes Received by Candidate: ")))
print("\n")

# Get Min (loser), Max(Winner) and Total
Total = 0
min = CanVotes[0]
max = CanVotes[0]
WinnerlOC = -1

# for vote in CanVotes:
#     Total += vote
#     if vote > max:
#         max = vote
#     elif Total < vote:
#         min = vote

# Was Trying to get winner and loser but not working so left out.
for i, vote in enumerate(CanVotes):
    Total += vote
    if vote > max:
        max = vote
        i = CanName[i]
        Winner = i
    elif Total < vote:
        min = vote
        # i = CanName[i]  # Can't get lowest place working
        # Loser = i

# print("Winner is {}".format(Winner))
# print("Loser is {}".format(Loser))

# Calculate % of votes for each Candidate
ListPercentage = []
for Percentage in range(0,CandidatesNumber):
    ExtractPercentage = CanVotes[Percentage]
    TotalPercentage = (ExtractPercentage/Total) * 100
    TotalPercentage = round(TotalPercentage,0)
    ListPercentage.append(TotalPercentage)
#print(ListPercentage) # leave outside loop so prints full list (will be printed below in final Output)
print("*** Below is a Summary of Results ***")
print("The Total votes Received where {} votes".format(Total))
print("The highest votes received by an individual candidate was {} votes".format(max))
print("The lowest votes received by a candidate was {} votes".format(min))
Average = (Total/CandidatesNumber)
print("The Average number of votes was {}\n".format(Average))


# Output names and votes
print("A Comprehensive breakdown of scores is outlined below")
print("{} {:>20} {:>20}%".format("Candidate","Votes Received","% of Total Votes")) #padding added to ensure formatting consistent
for i in range(0,CandidatesNumber):
    print("{} {:>20} {:>20}%\n".format(CanName[i],CanVotes[i],ListPercentage[i]))

# Output the Winner and Lowest Place
print("The winner of the Election is {}".format(Winner))
# print("The Person with the lowest votes was {}".format(LowestVotedPerson)) # see above can't get working