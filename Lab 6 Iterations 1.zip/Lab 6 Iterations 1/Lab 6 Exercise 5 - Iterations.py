# Write a program that asks the user to enter a String. Calculate and count the number of spaces in
# the String entered. Print the number of spaces.
# Based on the number of spaces print the word count for that sentence (you can assume that the
# sentence is entered correctly follows usual format for an English sentence).

UserInput = input("Describe your day in one sentence: ")
TotalSpaces = UserInput.count(" ") # Counts the number of Spaces
print("There are {} spaces in the sentence".format(TotalSpaces)) # Prints the number of spaces
TotalWords = UserInput.split() # Splits the words up
print("The words {} are in the sentence".format(TotalWords))
TotalLength = len(UserInput) # Gives the length of the sentence
print("The length of the sentence string is {}".format(TotalLength)) # prints the lenth of the sentence

while TotalSpaces >0:
    WordCount = TotalSpaces + 1 # There are 1 more word that space once more than one word entered.
    print("The total word count for the sentence is {}".format(WordCount)) # prints word count
    break

print("Loop ended") # Advises Loop ended


