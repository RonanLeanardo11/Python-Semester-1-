# Exercise 1.
# Design and develop a program which adds the up the numbers between 50 and 100. Use a while loop.
# Ronan Breen/ X00152190

# Input
Counter = 50 # Set starting position to 50

# Formula and Output
while Counter in range (50, 101): # Sets range for loop from 50-100
    print(Counter)
    Counter += 1 #increments 50 by 1 until reaches top range of 100

print("Loop is Finished") # Advises loop is finished