# Write a currency conversion program that first asks the user to type in today’s price (rate) of one euro
# in Japanese Yen, i.e. the yen rate (approximately 131.96 yen).
# The program should then ask the user to input a euro amount and while the euro amount entered is
# not 0 the loop should convert the euro amount to the Japanese yen equivalent and print the yen value
# for each. The loop will continue to read in another euro amount and convert it until the user enters 0
# as the euro amount.
# Ronan Breen/ X00152190

# Input
UserInputYen = float(input("Please enter today's price in Yen: "))

# ConversionFactor
YenToEuro = 1/131.96
# print(YenToEuro) # checking correct value i.e.0.00757. Commented out.
EurotoYen = 131.96

# Output
EuroValue = UserInputYen * YenToEuro # Calculations to convert inputted Yen Value to Euro
# print(EuroValue) checking Yen value correctly converts to €1. Commented out.

# Formula and Output
UserInputEuro = float(input("Please enter today's price in Euro(€): ")) # User enters value in €
while UserInputEuro != 0: # Statement to loop process while user inputs not equal to 0. Will complete once user enters 0
    UserInputEuro = UserInputEuro * EurotoYen # Convert Euro Value to Yen equivalent
    UserInputEuro = round(UserInputEuro,2) # Round to 2 places
    print("The value of your input in Yen is {}".format(UserInputEuro)) # Print Yen Value
    UserInputEuro = float(input("Please enter today's price in Euro(€): ")) # Repeat this while User inoput not equal to 0
    #break
print("Loop finished as nil value given") # Print this when Loop finished i.e. UserInput = 0