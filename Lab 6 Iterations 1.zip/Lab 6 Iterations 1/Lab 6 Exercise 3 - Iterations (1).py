# Exercise 3.
# Write a program that sums all the odd numbers between 1 and 20 inclusively and also sums the even
# numbers between 1 and 20 in the same loop. Print both results. Desk check your resulting answers.
# Ronan Breen/X00152190

#Input
Numbers = 0
#OddNumbers = 0
#EvenNumbers = 0

#Formula
for Numbers in range (1,21): # Go to 21 as it will cut off at 20 and we want that included.
    if Numbers % 2 == 0:
        print("The Even Numbers are {}".format(Numbers)) # Shows the Even Numbers
        Numbers += 1
    elif Numbers % 2 != 0:
       print("The Odd Numbers are {}".format(Numbers)) # Shows the Odd Numbers
       Numbers += 1

        # Above all Even and Odd numbers will print between 1,20

print("Loop is Finished") # Close Loop