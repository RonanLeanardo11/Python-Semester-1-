# Exercise 2.
# Design and develop a program that allows a user to type in 5 floating point numbers using a while
# loop. Read in each of the numbers and sum them up inside the loop. Calculate and print the average
# outside the loop.
# Ronan Breen/ X00152190

# Menu
print("***************************************")
print("******     Final Year Scores    *******")
print("** Note: Each CA has a 20% weighting **")
print("\n")
# Inputs
UserInput1 = float(input("Please enter % in CA1 between 0 - 20%: ")) # User enters a value between 0 - 20.
UserInput2 = float(input("Please enter % in CA2 between 0 - 20%: "))
UserInput3 = float(input("Please enter % in CA3 between 0 - 20%: "))
UserInput4 = float(input("Please enter % in CA4 between 0 - 20%: "))
UserInput5 = float(input("Please enter % in CA5 between 0 - 20%: "))

#Conditions
MinPercentage = 0 #hardcoded values below
MaxPercentage = 100 #hardcoded values below
SumInputs = (UserInput1 + UserInput2 + UserInput3 + UserInput4 + UserInput5) # will Determine our loop

while SumInputs < 0  or SumInputs > 100: # 5 scores cant be less than 0& or greater than 100% so if they are we want to display overall mark and advise them to reenter their scores until between 0-100.
    print("The combined Value cannot be less than 0% or greater than 100%") # Advise them can't be below 0% above 100%
    UserInput1 = float(input("Please reenter % in CA1 between 0 - 20%: ")) # User enters a value between 0 - 20.
    UserInput2 = float(input("Please reenter % in CA2 between 0 - 20%: "))
    UserInput3 = float(input("Please reenter % in CA3 between 0 - 20%: "))
    UserInput4 = float(input("Please reenter % in CA4 between 0 - 20%: "))
    UserInput5 = float(input("Please reenter % in CA5 between 0 - 20%: "))
    SumInputs = (UserInput1 + UserInput2 + UserInput3 + UserInput4 + UserInput5) # Add all the values entered..
    SumInputs = round(SumInputs,2)
    print("Your Final year score is {}%".format(SumInputs)) # Display final Score

#print("Loop is Finished") - Test Loop finishes correctly
if SumInputs >= 0 or SumInputs <= 100:
   print("Your Final year score is {}%".format(SumInputs)) # Display final score for those who never went into the loop i.e. if they entered a correct score under 100% total.

AvgInputs = (UserInput1 + UserInput2 + UserInput3 + UserInput4 + UserInput5)/ 5 # Get average by dividing by 5 i.e. 5 CA's
AvgInputs = round(AvgInputs,2)
print("Your Average score per CA is {}% out of 20%".format(AvgInputs)) # Print Average