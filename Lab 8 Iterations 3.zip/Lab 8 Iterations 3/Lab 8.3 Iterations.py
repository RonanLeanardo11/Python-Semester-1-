# Ronan Breen Lab 8.3 X00152190

# Input
WeeklyHoursAss1 = int(input("Enter hours worked this week by Research Assistant 1: "))
WeeklyHoursAss2 = int(input("Enter hours worked this week by Research Assistant 2: "))
WeeklyHoursAss3 = int(input("Enter hours worked this week by Research Assistant 3: "))

# Variables
ResearchAssistants = 3
DaysWorkingWeek = 5
AverageWorkingDay = 6
NormalHoursPerWeek = DaysWorkingWeek * AverageWorkingDay
Counter = 0

# Calculations for Daily Hours
DailyHoursAss1 = (WeeklyHoursAss1/DaysWorkingWeek)
print(DailyHoursAss1)
DailyHoursAss2 = (WeeklyHoursAss2/DaysWorkingWeek)
print(DailyHoursAss2)
DailyHoursAss3 = (WeeklyHoursAss3/DaysWorkingWeek)
print(DailyHoursAss3)

for hours in range(0, ResearchAssistants):
    if WeeklyHoursAss1 > NormalHoursPerWeek or WeeklyHoursAss2 > NormalHoursPerWeek or WeeklyHoursAss3 > NormalHoursPerWeek:
        Counter += 1

print(Counter)



