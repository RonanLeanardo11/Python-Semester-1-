# Ronan Breen Lab 8.2 X00152190

# Input
Rows = int(input("Please enter number of rows: "))

# Output
for row in range(Rows, 1, -1): # start from row input down to 1, decreasing by 1.
    for column in range((row - 1)): # set column to one less than row.
        print("*", end="")
    print()