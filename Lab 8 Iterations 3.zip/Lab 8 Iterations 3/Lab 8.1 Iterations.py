# Ronan Breen Lab 8.1 X00152190

# Inputs
UserInput = int(input("Please enter a number: "))

# Variables
Solution = 1

# Output
for i in range(UserInput):
    Solution = Solution *(i + 1) # Solution and i increments.
    Iteration = (UserInput * i)
    print("Solution = {} * {}".format(UserInput, i))
   # NewNumber = Solution
print("Solution is the addition of above solutions to equal {}".format(Solution))

